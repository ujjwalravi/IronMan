console.log('hello workld');


function triggerChart(name) {
	console.log("Triggered");
	google.charts.load('current', {'packages':['corechart']});
	google.charts.setOnLoadCallback(drawChart(name));
	document.getElementById('chart_container').style.display = "block";
}

function drawChart(name) {
        // Create the data table.
        var data = google.visualization.arrayToDataTable([
          ['Year', 'Sales', 'Expenses'],
          ['2004',  1000,      400],
          ['2005',  1170,      460],
          ['2006',  660,       1120],
          ['2007',  1030,      540]
        ]);

        var options = {
          title: name,
          curveType: 'function',
          legend: { position: 'bottom' },
          width:1200,
          height:500
        };

        var chart = new google.visualization.LineChart(document.getElementById('chrt'));

        chart.draw(data, options);
}