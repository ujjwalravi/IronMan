console.log('hello inventory');
google.charts.load('current', {packages: ['corechart', 'bar']});
google.charts.setOnLoadCallback(drawBasic);


function drawBasic() {

      var data = google.visualization.arrayToDataTable([
        ['City', 'Sales',],
        ['Product 1', 81750],
        ['Product 2', 37920],
        ['Product 3', 26950],
        ['Product 4', 20990],
      ]);

      var options = {
        title: 'Total Sales of our Products',
        chartArea: {width: '50%'},
        hAxis: {
          title: 'Total Population',
          minValue: 0
        },
        vAxis: {
          title: 'City'
        },
        width:1200,
        height:500
      };

      var chart = new google.visualization.BarChart(document.getElementById('chrt'));

      chart.draw(data, options);
    }