const count1 = document.querySelector(".countdown_1");
let num = 0;
// count.textContent = "0";
// num = count.textContent;
var anish = setInterval(() => {
  if (Number(count1.textContent) === 65) {
    clearInterval(anish);
    return;
  }
  num++;
  count1.textContent = `${num}`;
}, 10);

const count2 = document.querySelector(".countdown_2");
let num2 = 0;
var aman = setInterval(() => {
  if (Number(count2.textContent) === 50) {
    clearInterval(aman);
    return;
  }
  num2++;
  count2.textContent = `${num2}`;
}, 10);
const count3 = document.querySelector(".countdown_3");
let num3 = 0;
// // count.textContent = "0";
// // num = count.textContent;
var bijoy = setInterval(() => {
  if (Number(count3.textContent) === 200) {
    clearInterval(bijoy);
    return;
  }
  num3++;
  count3.textContent = `${num3}`;
}, 10);
